console.log("hello world")
const ans=require("./second")
console.log(ans)