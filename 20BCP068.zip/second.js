kunal={name:"kunal",
num: 68
}
module.exports=kunal
console.log(exports,require,module,__filename,__dirname)